<?php
$shit = "1/1/1111";
if(is_numeric($shit)){
    echo "wow";
}else{
    echo "loser";
}
                        
?>