<?php
    require_once('inc/config.php'); class Sanitizer { public static function Gentle ($str){ return strip_tags(preg_replace('/[[:^print:]]/', '', $str)); } public static function Harsh($str){ $str = str_replace(' ', '', $str); return strip_tags(preg_replace('/[^A-Za-z0-9\-]/', '', $str)); }}
?>

<html>
    <head>
        <title><?php echo $site_name; ?> - <?php echo $pageName; ?></title>
        <link rel="shortcut icon" type="image/ico" href="inc/favicon.ico"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">
        <link rel="stylesheet" href="inc/theme2.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>
    </head>
    <body>
    